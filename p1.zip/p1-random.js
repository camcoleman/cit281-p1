/*
    CIT 281 Project 1
    Name: Cameron Coleman
*/

function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

let length = getRandomInteger(5,25);
let string = ""
let alphabet = "abcdefghijklmnopqrstuvwxyz";

for (let i = 0; i < length; i++) {
    string += alphabet[getRandomInteger(0, alphabet.length)];
}
console.log(length + " lowercase letters: " + string );