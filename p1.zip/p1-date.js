/* 
CIT 281 Project 1
Name: Cameron Coleman
*/
console.log(["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][new Date().getDay()]);

